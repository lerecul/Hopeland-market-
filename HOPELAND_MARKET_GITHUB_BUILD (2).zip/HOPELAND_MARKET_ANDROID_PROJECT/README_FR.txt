HOPELAND MARKET — Projet Android

Ce dossier est un projet source Android Studio (application WebView) contenant la boutique et le logo officiel.

Pour générer l'APK :
1. Installer Android Studio sur un ordinateur.
2. Ouvrir le dossier HOPELAND_MARKET_ANDROID_PROJECT dans Android Studio.
3. Laisser Gradle synchroniser le projet (connexion Internet nécessaire au premier lancement).
4. Aller dans Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio générera l'APK dans app/build/outputs/apk/debug/.

Identifiant : com.hopelandmarket.app
Nom affiché : HOPELAND MARKET

IMPORTANT :
- Ce projet embarque la version web fournie.
- Le catalogue contient des produits et prix de démonstration indiqués dans la page.
- La commande WhatsApp est configurée sur le numéro déjà présent dans la page.
- Ce ZIP est le projet source, pas un APK déjà compilé.
